﻿namespace receivermp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_start_receiveing = new System.Windows.Forms.Button();
            this.tB_ip = new System.Windows.Forms.TextBox();
            this.tb_PORT = new System.Windows.Forms.TextBox();
            this.bt_stop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_start_receiveing
            // 
            this.bt_start_receiveing.Location = new System.Drawing.Point(104, 75);
            this.bt_start_receiveing.Name = "bt_start_receiveing";
            this.bt_start_receiveing.Size = new System.Drawing.Size(86, 44);
            this.bt_start_receiveing.TabIndex = 0;
            this.bt_start_receiveing.Text = "pocni";
            this.bt_start_receiveing.UseVisualStyleBackColor = true;
            this.bt_start_receiveing.Click += new System.EventHandler(this.bt_start_receiveing_Click);
            // 
            // tB_ip
            // 
            this.tB_ip.Location = new System.Drawing.Point(104, 143);
            this.tB_ip.Name = "tB_ip";
            this.tB_ip.Size = new System.Drawing.Size(100, 20);
            this.tB_ip.TabIndex = 1;
            // 
            // tb_PORT
            // 
            this.tb_PORT.Location = new System.Drawing.Point(104, 184);
            this.tb_PORT.Name = "tb_PORT";
            this.tb_PORT.Size = new System.Drawing.Size(100, 20);
            this.tb_PORT.TabIndex = 2;
            this.tb_PORT.TextChanged += new System.EventHandler(this.tb_PORT_TextChanged);
            // 
            // bt_stop
            // 
            this.bt_stop.Location = new System.Drawing.Point(317, 75);
            this.bt_stop.Name = "bt_stop";
            this.bt_stop.Size = new System.Drawing.Size(86, 44);
            this.bt_stop.TabIndex = 3;
            this.bt_stop.Text = "stop";
            this.bt_stop.UseVisualStyleBackColor = true;
            this.bt_stop.Click += new System.EventHandler(this.bt_stop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1120, 608);
            this.Controls.Add(this.bt_stop);
            this.Controls.Add(this.tb_PORT);
            this.Controls.Add(this.tB_ip);
            this.Controls.Add(this.bt_start_receiveing);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_start_receiveing;
        private System.Windows.Forms.TextBox tB_ip;
        private System.Windows.Forms.TextBox tb_PORT;
        private System.Windows.Forms.Button bt_stop;
    }
}

