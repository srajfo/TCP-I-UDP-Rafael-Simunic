﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using NAudio.Wave;

namespace receivermp3
{
    public partial class Form1 : Form
    {
        private UdpClient udpClient;
        private WaveOutEvent waveOut;
        private BufferedWaveProvider bufferProvider;
        private Thread receiveThread;
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_start_receiveing_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(tb_PORT.Text, out int port))
            {
                MessageBox.Show("Neispravan port");
                return;
            }

            udpClient = new UdpClient(port);

            bufferProvider = new BufferedWaveProvider(new WaveFormat(16000, 16, 1));
            bufferProvider.DiscardOnBufferOverflow = true;

            waveOut = new WaveOutEvent();
            waveOut.Init(bufferProvider);
            waveOut.Play();

            receiveThread = new Thread(ReceiveAudio) { IsBackground = true };
            receiveThread.Start();

            bt_start_receiveing.Enabled = false;
            bt_stop.Enabled = true;
        }
        private void ReceiveAudio()
        {
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);

            while (true)
            {
                try
                {
                    byte[] data = udpClient.Receive(ref remoteEP);
                    bufferProvider.AddSamples(data, 0, data.Length);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greška u prijemu: " + ex.Message);
                    break;
                }
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            udpClient?.Close();
            waveOut?.Stop();
            waveOut?.Dispose();
        }

        private void tb_PORT_TextChanged(object sender, EventArgs e)
        {

        }

        private void bt_stop_Click(object sender, EventArgs e)
        {
            receiveThread?.Abort(); 
            udpClient?.Close();
            waveOut?.Stop();
            waveOut?.Dispose();
            udpClient = null;
            waveOut = null;

            bt_start_receiveing.Enabled = true;
            bt_stop.Enabled = false;
        }
    }
}

