﻿namespace senderMP3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.bt_select_file = new System.Windows.Forms.Button();
            this.bt_start = new System.Windows.Forms.Button();
            this.tB_IP = new System.Windows.Forms.TextBox();
            this.tB_PORT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_stop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // bt_select_file
            // 
            this.bt_select_file.Location = new System.Drawing.Point(12, 12);
            this.bt_select_file.Name = "bt_select_file";
            this.bt_select_file.Size = new System.Drawing.Size(374, 145);
            this.bt_select_file.TabIndex = 0;
            this.bt_select_file.Text = "odaberi file";
            this.bt_select_file.UseVisualStyleBackColor = true;
            this.bt_select_file.Click += new System.EventHandler(this.bt_select_file_Click);
            // 
            // bt_start
            // 
            this.bt_start.Location = new System.Drawing.Point(407, 12);
            this.bt_start.Name = "bt_start";
            this.bt_start.Size = new System.Drawing.Size(374, 145);
            this.bt_start.TabIndex = 1;
            this.bt_start.Text = "start";
            this.bt_start.UseVisualStyleBackColor = true;
            this.bt_start.Click += new System.EventHandler(this.bt_start_Click);
            // 
            // tB_IP
            // 
            this.tB_IP.Location = new System.Drawing.Point(114, 201);
            this.tB_IP.Name = "tB_IP";
            this.tB_IP.Size = new System.Drawing.Size(100, 20);
            this.tB_IP.TabIndex = 2;
            // 
            // tB_PORT
            // 
            this.tB_PORT.Location = new System.Drawing.Point(114, 253);
            this.tB_PORT.Name = "tB_PORT";
            this.tB_PORT.Size = new System.Drawing.Size(100, 20);
            this.tB_PORT.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 208);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "IP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "PORT";
            // 
            // bt_stop
            // 
            this.bt_stop.Location = new System.Drawing.Point(407, 201);
            this.bt_stop.Name = "bt_stop";
            this.bt_stop.Size = new System.Drawing.Size(374, 145);
            this.bt_stop.TabIndex = 6;
            this.bt_stop.Text = "stop";
            this.bt_stop.UseVisualStyleBackColor = true;
            this.bt_stop.Click += new System.EventHandler(this.bt_stop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1293, 597);
            this.Controls.Add(this.bt_stop);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tB_PORT);
            this.Controls.Add(this.tB_IP);
            this.Controls.Add(this.bt_start);
            this.Controls.Add(this.bt_select_file);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button bt_select_file;
        private System.Windows.Forms.Button bt_start;
        private System.Windows.Forms.TextBox tB_IP;
        private System.Windows.Forms.TextBox tB_PORT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_stop;
    }
}

