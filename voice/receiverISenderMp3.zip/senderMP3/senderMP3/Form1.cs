﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NAudio.Wave;

namespace senderMP3
{
    public partial class Form1 : Form
    {
        private UdpClient udpClient;
        private IPEndPoint remoteEndPoint;
        private WaveInEvent waveIn;

        public Form1()
        {
            InitializeComponent();
            udpClient = new UdpClient();
        }

        private void bt_select_file_Click(object sender, EventArgs e)
        {

        }
        private async void bt_start_Click(object sender, EventArgs e)
        {
            string ip = tB_IP.Text;
            if (!int.TryParse(tB_PORT.Text, out int port))
            {
                MessageBox.Show("Neispravan port");
                return;
            }

            remoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);

            waveIn = new WaveInEvent();
            waveIn.WaveFormat = new WaveFormat(16000, 16, 1); // 16kHz, 16bit, mono
            waveIn.DataAvailable += WaveIn_DataAvailable;
            waveIn.StartRecording();

            bt_select_file.Enabled = false;
            bt_start.Enabled = false;
            bt_stop.Enabled = true;

        }
        private void WaveIn_DataAvailable(object sender, WaveInEventArgs e)
        {
            udpClient.Send(e.Buffer, e.BytesRecorded, remoteEndPoint);
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            waveIn?.StopRecording();
            udpClient?.Close();
        }

        private void bt_stop_Click(object sender, EventArgs e)
        {
            waveIn?.StopRecording();
            waveIn?.Dispose();
            waveIn = null;

            bt_start.Enabled = true;
            bt_stop.Enabled = false;
        }
    }
}