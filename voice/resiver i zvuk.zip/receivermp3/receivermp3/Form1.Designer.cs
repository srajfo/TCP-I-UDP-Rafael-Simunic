﻿namespace receivermp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_start_receiveing = new System.Windows.Forms.Button();
            this.tB_ip = new System.Windows.Forms.TextBox();
            this.tb_PORT = new System.Windows.Forms.TextBox();
            this.bt_stop = new System.Windows.Forms.Button();
            this.bt_start_receiveing_TCP = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_receiver = new System.Windows.Forms.Label();
            this.lb_konekcija = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_start_receiveing
            // 
            this.bt_start_receiveing.Location = new System.Drawing.Point(88, 186);
            this.bt_start_receiveing.Name = "bt_start_receiveing";
            this.bt_start_receiveing.Size = new System.Drawing.Size(153, 56);
            this.bt_start_receiveing.TabIndex = 0;
            this.bt_start_receiveing.Text = "start UDP";
            this.bt_start_receiveing.UseVisualStyleBackColor = true;
            this.bt_start_receiveing.Click += new System.EventHandler(this.bt_start_receiveing_Click);
            // 
            // tB_ip
            // 
            this.tB_ip.Location = new System.Drawing.Point(132, 73);
            this.tB_ip.Name = "tB_ip";
            this.tB_ip.Size = new System.Drawing.Size(100, 20);
            this.tB_ip.TabIndex = 1;
            this.tB_ip.TextChanged += new System.EventHandler(this.tB_ip_TextChanged);
            // 
            // tb_PORT
            // 
            this.tb_PORT.Location = new System.Drawing.Point(132, 113);
            this.tb_PORT.Name = "tb_PORT";
            this.tb_PORT.Size = new System.Drawing.Size(100, 20);
            this.tb_PORT.TabIndex = 2;
            this.tb_PORT.TextChanged += new System.EventHandler(this.tb_PORT_TextChanged);
            // 
            // bt_stop
            // 
            this.bt_stop.Location = new System.Drawing.Point(88, 349);
            this.bt_stop.Name = "bt_stop";
            this.bt_stop.Size = new System.Drawing.Size(153, 62);
            this.bt_stop.TabIndex = 3;
            this.bt_stop.Text = "stop";
            this.bt_stop.UseVisualStyleBackColor = true;
            this.bt_stop.Click += new System.EventHandler(this.bt_stop_Click);
            // 
            // bt_start_receiveing_TCP
            // 
            this.bt_start_receiveing_TCP.Location = new System.Drawing.Point(88, 266);
            this.bt_start_receiveing_TCP.Name = "bt_start_receiveing_TCP";
            this.bt_start_receiveing_TCP.Size = new System.Drawing.Size(153, 55);
            this.bt_start_receiveing_TCP.TabIndex = 4;
            this.bt_start_receiveing_TCP.Text = "start TCP";
            this.bt_start_receiveing_TCP.UseVisualStyleBackColor = true;
            this.bt_start_receiveing_TCP.Click += new System.EventHandler(this.bt_start_receiveing_TCP_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "IP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "PORT";
            // 
            // lb_receiver
            // 
            this.lb_receiver.AutoSize = true;
            this.lb_receiver.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_receiver.Location = new System.Drawing.Point(405, 43);
            this.lb_receiver.Name = "lb_receiver";
            this.lb_receiver.Size = new System.Drawing.Size(270, 55);
            this.lb_receiver.TabIndex = 7;
            this.lb_receiver.Text = "RECEIVER";
            // 
            // lb_konekcija
            // 
            this.lb_konekcija.AutoSize = true;
            this.lb_konekcija.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_konekcija.Location = new System.Drawing.Point(94, 440);
            this.lb_konekcija.Name = "lb_konekcija";
            this.lb_konekcija.Size = new System.Drawing.Size(147, 25);
            this.lb_konekcija.TabIndex = 8;
            this.lb_konekcija.Text = "ne prima se zvuk";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1120, 608);
            this.Controls.Add(this.lb_konekcija);
            this.Controls.Add(this.lb_receiver);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_start_receiveing_TCP);
            this.Controls.Add(this.bt_stop);
            this.Controls.Add(this.tb_PORT);
            this.Controls.Add(this.tB_ip);
            this.Controls.Add(this.bt_start_receiveing);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_start_receiveing;
        private System.Windows.Forms.TextBox tB_ip;
        private System.Windows.Forms.TextBox tb_PORT;
        private System.Windows.Forms.Button bt_stop;
        private System.Windows.Forms.Button bt_start_receiveing_TCP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_receiver;
        private System.Windows.Forms.Label lb_konekcija;
    }
}

