﻿using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace receivermp3
{
    public partial class Form1 : Form
    {

        private UdpClient udpClient;
        private WaveOutEvent waveOut;
        private BufferedWaveProvider bufferProvider;
        private Thread receiveThread;
        private TcpListener listener;
        private Thread listenThread;
        private bool isRunning = false;

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
            this.FormClosing += Form1_FormClosing;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            StyleUI();
        }
        private void StyleUI()
        {
           
            this.BackColor = Color.FromArgb(54, 57, 63); 
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI", 10);

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Button btn)
                {
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.BackColor = Color.FromArgb(88, 101, 242);
                    btn.ForeColor = Color.White;
                    btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                    btn.Height = 35;
                    btn.Width = 160;
                    btn.Margin = new Padding(10);
                }
                else if (ctrl is TextBox tb)
                {
                    tb.BackColor = Color.FromArgb(64, 68, 75); 
                    tb.ForeColor = Color.White;
                    tb.BorderStyle = BorderStyle.FixedSingle;
                }
                else if (ctrl is Label lbl)
                {
                    lbl.ForeColor = Color.White;
                }
            }
            bt_stop.BackColor = Color.FromArgb(237, 66, 69);
            lb_konekcija.ForeColor = Color.Red;
        }
        public class RoundedButton : Button
        {
            protected override void OnPaint(PaintEventArgs pevent)
            {
                base.OnPaint(pevent);
                GraphicsPath g = new GraphicsPath();
                g.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height);
                this.Region = new Region(g);
            }
        }

        private void bt_start_receiveing_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(tb_PORT.Text, out int port))
            {
                MessageBox.Show("Neispravan port");
                return;
            }

            udpClient = new UdpClient(port);

            bufferProvider = new BufferedWaveProvider(new WaveFormat(16000, 16, 1));
            bufferProvider.DiscardOnBufferOverflow = true;

            waveOut = new WaveOutEvent();
            waveOut.Init(bufferProvider);
            waveOut.Play();

            receiveThread = new Thread(ReceiveAudio) { IsBackground = true };
            receiveThread.Start();

            bt_start_receiveing.Enabled = false;
            bt_start_receiveing_TCP.Enabled = false;
            bt_start_receiveing.BackColor = Color.White;
            bt_start_receiveing_TCP.BackColor = Color.White;
            bt_stop.Enabled = true;
            lb_konekcija.Text = "Konekcija(prima) :UDP";
            lb_konekcija.ForeColor = Color.Green;
        }
        private void ReceiveAudio()
        {
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);

            while (true)
            {
                try
                {
                    byte[] data = udpClient.Receive(ref remoteEP);
                    bufferProvider.AddSamples(data, 0, data.Length);
                }
                catch (Exception ex)
                {
                   /* MessageBox.Show("Greška " +  ex.Message);
                    break;*/
                }
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            udpClient?.Close();
            waveOut?.Stop();
            waveOut?.Dispose();
        }

        private void tb_PORT_TextChanged(object sender, EventArgs e)
        {

        }

        private void bt_stop_Click(object sender, EventArgs e)
        {
            isRunning = false;
            listener?.Stop();
            receiveThread?.Abort(); 
            udpClient?.Close();
            waveOut?.Stop();
            waveOut?.Dispose();
            udpClient = null;
            waveOut = null;
            listener = null;

            bt_start_receiveing.Enabled = true;
            bt_start_receiveing.BackColor=Color.FromArgb(88, 101, 242); ;
            bt_start_receiveing_TCP.Enabled = true;
            bt_start_receiveing_TCP.BackColor= Color.FromArgb(88, 101, 242);
            bt_stop.Enabled = false;
            lb_konekcija.Text = "ne prima se zvuk";
            lb_konekcija.ForeColor = Color.Red;
        }

        private void bt_start_receiveing_TCP_Click(object sender, EventArgs e)
        {
            int port = int.Parse(tb_PORT.Text);
            listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            isRunning = true;

            listenThread = new Thread(ListenLoop) { IsBackground = true };
            listenThread.Start();

            bt_start_receiveing.Enabled = false;
            bt_start_receiveing.BackColor= Color.White;
            bt_start_receiveing_TCP.Enabled = false;
            bt_start_receiveing_TCP.BackColor= Color.White;
            bt_stop.Enabled = true;
            lb_konekcija.Text = "Konekcija(prima) :TCP";
            lb_konekcija.ForeColor = Color.Green;
        }
        private void ListenLoop()
        {
            try
            {
                while (isRunning)
                {
                    using (TcpClient client = listener.AcceptTcpClient())
                    using (NetworkStream stream = client.GetStream())
                    {
                        bufferProvider = new BufferedWaveProvider(new WaveFormat(16000, 16, 1));
                        bufferProvider.DiscardOnBufferOverflow = true;

                        waveOut = new WaveOutEvent();
                        waveOut.Init(bufferProvider);
                        waveOut.Play();

                        byte[] buffer = new byte[4096];
                        int bytesRead;

                        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0 && isRunning)
                        {
                            bufferProvider.AddSamples(buffer, 0, bytesRead);
                        }

                        waveOut.Stop();
                        waveOut.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Greška: " + ex.Message);
            }
        }

        private void tB_ip_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
    }
}

