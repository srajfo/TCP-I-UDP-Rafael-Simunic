﻿using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace senderMP3
{
    public partial class Form1 : Form
    {
        private UdpClient udpClient;
        private IPEndPoint remoteEndPoint;
        private WaveInEvent waveIn;
        private TcpClient client;
        private NetworkStream stream;

        public Form1()
        {
            InitializeComponent();
            udpClient = new UdpClient();
            this.Load += Form1_Load;
            this.FormClosing += Form1_FormClosing;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            StyleUI();
        }
        private void StyleUI()
        {
        
            this.BackColor = Color.FromArgb(54, 57, 63);
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI", 10);

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Button btn)
                {
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.BackColor = Color.FromArgb(88, 101, 242); 
                    btn.ForeColor = Color.White;
                    btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                    btn.Height = 35;
                    btn.Width = 160;
                    btn.Margin = new Padding(10);
                }
                else if (ctrl is TextBox tb)
                {
                    tb.BackColor = Color.FromArgb(64, 68, 75); 
                    tb.ForeColor = Color.White;
                    tb.BorderStyle = BorderStyle.FixedSingle;
                }
                else if (ctrl is Label lbl)
                {
                    lbl.ForeColor = Color.White;
                }
            }
            bt_stop.BackColor = Color.FromArgb(237, 66, 69);
            lb_konekcija.ForeColor = Color.Red;
        }
        public class RoundedButton : Button
        {
            protected override void OnPaint(PaintEventArgs pevent)
            {
                base.OnPaint(pevent);
                GraphicsPath g = new GraphicsPath();
                g.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height);
                this.Region = new Region(g);
            }
        }

        private void bt_select_file_Click(object sender, EventArgs e)
        {

        }
        private async void bt_start_Click(object sender, EventArgs e)
        {
            string ip = tB_IP.Text;
            if (!int.TryParse(tB_PORT.Text, out int port))
            {
                MessageBox.Show("Neispravan port");
                return;
            }

            remoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);

            waveIn = new WaveInEvent();
            waveIn.WaveFormat = new WaveFormat(16000, 16, 1); 
            waveIn.DataAvailable += WaveIn_DataAvailable;
            waveIn.StartRecording();

            bt_start.Enabled = false;
            bt_start.BackColor = Color.White;
            bt_start_TCP.Enabled = false;
            bt_start_TCP.BackColor = Color.White;
            bt_stop.Enabled = true;
            lb_konekcija.Text = "Konekcija(prima):UDP";
            lb_konekcija.ForeColor = Color.Green;

        }
        private void WaveIn_DataAvailable(object sender, WaveInEventArgs e)
        {
            udpClient.Send(e.Buffer, e.BytesRecorded, remoteEndPoint);
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            waveIn?.StopRecording();
            udpClient?.Close();
        }

        private void bt_stop_Click(object sender, EventArgs e)
        {
            waveIn?.StopRecording();
            waveIn?.Dispose();
            waveIn = null;
            stream?.Close();
            client?.Close();

            bt_start.Enabled = true;
            bt_start.BackColor = Color.FromArgb(88, 101, 242);
            bt_start_TCP.Enabled = true;
            bt_start_TCP.BackColor = Color.FromArgb(88, 101, 242);
            bt_stop.Enabled = false;
            lb_konekcija.Text = "ne salje se zvuk";
            lb_konekcija.ForeColor = Color.Red;
        }

        private void bt_start_TCP_Click(object sender, EventArgs e)
        {
            try
            {
                client = new TcpClient(tB_IP.Text, int.Parse(tB_PORT.Text));
                stream = client.GetStream();

                waveIn = new WaveInEvent
                {
                    WaveFormat = new WaveFormat(16000, 16, 1)
                };
                waveIn.DataAvailable += WaveIn_DataAvailableTCP;
                waveIn.StartRecording();

                bt_start.Enabled = false;
                bt_start.BackColor = Color.White;
                bt_start_TCP.Enabled = false;
                bt_start_TCP.BackColor = Color.White;
                bt_stop.Enabled = true;
                lb_konekcija.Text = "Konekcija(salje):TCP";
                lb_konekcija.ForeColor = Color.Green;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
        }
        private void WaveIn_DataAvailableTCP(object sender, WaveInEventArgs e)
        {
            try
            {
                stream.Write(e.Buffer, 0, e.BytesRecorded);
            }
            catch (Exception)
            {
                
            }
        }
    }
}
